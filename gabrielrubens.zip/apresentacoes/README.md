O PROGRAMADOR PRAGMÁTICO
DE APRENDIZ A MESTRE
========================

Apresentação com um resumo de alguns pontos importantes do livro

Essa apresentação poderá ser vista em http://gabrielrubens.com.br/apresentacoes/o-programador-pragmatico
